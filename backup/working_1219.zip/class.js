function class_drug(gender, drug_concept_id, drug_exposure_start_date, drug_exposure_end_date, quantity, days_supply, dose_unit_source_value){
    var obj = {
        gender: gender,
        drug_concept_id: drug_concept_id,
        drug_exposure_start_date: drug_exposure_start_date,
        drug_exposure_end_date: drug_exposure_end_date,
        quantity: quantity,
        days_supply: days_supply,
        dose_unit_source_value: dose_unit_source_value
    }
    return obj;
}
function class_measurement(gender, measurement_concept_id, measurement_date, value_as_number, range_low, range_high, unit_source_value){
    var obj = {
        gender: gender,
        measurement_concept_id: measurement_concept_id,
        measurement_date: measurement_date,
        value_as_number: value_as_number,
        range_low: range_low,
        range_high: range_high,
        unit_source_value: unit_source_value
    }
    return obj;
}
function class_condition(gender, condition_concept_id, condition_start_date) {
    var obj = {
        gender: gender,
        condition_concept_id: condition_concept_id,
        condition_start_date: condition_start_date
    }
    return obj;
}
function class_visit(gender, visit_concept_id, visit_start_date, visit_end_date, care_site_id) {
    var obj = {
        gender: gender,
        visit_concept_id: visit_concept_id,
        visit_start_date: visit_start_date,
        visit_end_date: visit_end_date,
        care_site_id:care_site_id
    }
    return obj;
}


function class_person(gender, year) {
    var obj = {
        gender: gender,
        year: year
    }
    return obj
}

function class_distribution_result(name, value){
    var obj ={
        name : name,
        value : value
    }
    return obj;
}

module.exports ={
    class_drug,
    class_measurement,
    class_condition,
    class_visit,
    class_person,
    class_distribution_result
}

