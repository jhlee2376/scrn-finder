'use strict';
require('./test-basic');
require('./test-big-buffer');
require('./test-stream');
