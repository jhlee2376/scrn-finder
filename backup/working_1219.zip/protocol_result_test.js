var diagnosis = {
    "age_distribution" : [10,20,30,40,50,60,70,80],
    "gender" : [80,190], 
    "visit_distribution" :[10,20,30]
}