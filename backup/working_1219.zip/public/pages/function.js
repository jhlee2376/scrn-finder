﻿

function myFunction() {
    var result =
    '<div class="panel panel-default">\
                        <div class="panel-heading">\
                            Collapsible Accordion Panel Group\
                        </div>\
                        <!-- .panel-heading -->\
                        <div class="panel-body">\
                            <div class="panel-group" id="accordion">\
                                <div class="panel panel-default">\
                                    <div class="panel-heading">\
                                        <h4 class="panel-title">\
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" class="collapsed">Collapsible Group Item #1</a>\
                                        </h4>\
                                    </div>\
                                    <div id="collapseOne" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">\
                                        <div class="panel-body">\
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\
                                        </div>\
                                    </div>\
                                </div>\
                                <div class="panel panel-default">\
                                    <div class="panel-heading">\
                                        <h4 class="panel-title">\
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" class="collapsed" aria-expanded="false">Collapsible Group Item #2</a>\
                                        </h4>\
                                    </div>\
                                    <div id="collapseTwo" class="panel-collapse collapse" aria-expanded="false">\
                                        <div class="panel-body">\
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\
                                        </div>\
                                    </div>\
                                </div>\
                                <div class="panel panel-default">\
                                    <div class="panel-heading">\
                                        <h4 class="panel-title">\
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree" class="collapsed" aria-expanded="false">Collapsible Group Item #3</a>\
                                        </h4>\
                                    </div>\
                                    <div id="collapseThree" class="panel-collapse collapse" aria-expanded="false">\
                                        <div class="panel-body">\
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\
                                        </div>\
                                    </div>\
                                </div>\
                            </div>\
                        </div>\
                        <!-- .panel-body -->\
                    </div>\
'+"a";
return result;
}
 
 
//  상단판넬
function topDescription(){
    var result='<div class="chat-panel panel panel-green" >\
    <div class="panel-heading">\
        Study Description<i class="fa fa-pencil fa-fw"></i>\
    </div>\
    <!-- /.panel-heading -->\
    <div class="panel-body">\
            <ul class="chat">\
                <div class="table-responsive">\
                        <table class="table">\
                            <thead>\
                                <tr>\
                                    <th>항목</th>\
                                    <th>내용</th>\
                                </tr>\
                            </thead>\
                            <tbody>\
                                <tr>\
                                    <td>Category</td>\
                                    <td>고혈압</td>\
                                </tr>\
                                <tr>\
                                    <td>Study Status</td>\
                                    <td>Draft</td>\
                                </tr>\
                                <tr>\
                                    <td>Creation Date</td>\
                                    <td>2018-05-19 13:00</td>\
                                </tr>\
                                <tr>\
                                    <td>Administrator</td>\
                                    <td>김민걸</td>\
                                </tr>\
                                <tr>\
                                    <td>Description</td>\
                                    <td>Tenofovir 복용 환자 수를 조회하고 연구한다.</td>\
                                </tr>\
                                \
                                \
                            </tbody>\
                        </table>\
                </div>\
            </ul>\
        <!-- /.table-responsive -->\
    </div>\
    <!-- /.panel-body -->\
</div>\
<!-- /.panel -->\
';
 
return result;
}
 
 
 
function topMember(){
    var result='<div class="chat-panel panel panel-primary">\
    <div class="panel-heading">\
            Member<i class="fa fa-pencil fa-fw"></i>\
    </div>\
    <!-- /.panel-heading -->\
    <div class="panel-body">\
        <!-- Nav tabs -->\
        <ul class="nav nav-tabs">\
                <li class="active"><a href="#home" data-toggle="tab"><b>일반멤버</b> <i class="fa fa-pencil fa-fw"></i></a>\
                </li>\
                <li><a href="#profile" data-toggle="tab"><b>책임관리자</b> <i class="fa fa-pencil fa-fw"></i></a>\
                </li>\
            </ul>\
\
            <!-- Tab panes -->\
            <div class="tab-content">\
                <div class="tab-pane fade in active" id="home">\
                        <div class="table-responsive">\
                                <table class="table table-striped">\
                                    <thead>\
                                        <tr>\
                                            <th>#</th>\
                                            <th>이름</th>\
                                            <th>직책</th>\
                                            <th>Access</th>\
                                            <th>Edit</th>\
                                            <th>Delete</th>\
                                        </tr>\
                                    </thead>\
                                    <tbody>\
                                        <tr>\
                                            <td>1</td>\
                                            <td>정상운</td>\
                                            <td>과장</td>\
                                            <td><input id=ch type="checkbox" value=""></td>\
                                            <td><input id=ch type="checkbox" value=""></td>\
                                            <td><input id=ch type="checkbox" value=""></td>\
                                        </tr>\
                                        <tr>\
                                            <td>2</td>\
                                            <td>김민지</td>\
                                            <td>사원</td>\
                                            <td><input id=ch type="checkbox" value=""></td>\
                                            <td><input id=ch type="checkbox" value=""></td>\
                                            <td></td>\
                                        </tr>\
                                        <tr>\
                                            <td>3</td>\
                                            <td>심상일</td>\
                                            <td>사원</td>\
                                            <td><input id=ch type="checkbox" value=""></td>\
                                            <td></td>\
                                            <td></td>\
                                        </tr>\
                                        <tr>\
                                            <td>4</td>\
                                            <td>김우성</td>\
                                            <td>사원</td>\
                                            <td><input id=ch type="checkbox" value=""></td>\
                                            <td></td>\
                                            <td></td>\
                                        </tr>\
                                    </tbody>\
                                </table>\
                            </div>\
                            <!-- table-responsive -->\
                </div>\
                <div class="tab-pane fade" id="profile">\
                        <div class="table-responsive">\
                                <table class="table table-striped">\
                                    <thead>\
                                        <tr>\
                                            <th>#</th>\
                                            <th >이름</th>\
                                            <th>소속</th>\
                                            <th>직책</th>\
                                            <th>협약상태</th>\
                                            </tr>\
                                    </thead>\
                                    <tbody>\
                                        <tr>\
                                            <td>1</td>\
                                            <td>정상운</td>\
                                            <td>의사</td>\
                                            <td>전북대병원</td>\
                                            <td><button type="button" class="btn btn-success">협약완료</button></td>\
                                        </tr>\
                                        <tr>\
                                            <td>2</td>\
                                            <td>김민지</td>\
                                            <td>의사</td>\
                                            <td>아주대병원</td>\
                                            <td><button type="button" class="btn btn-warning disabled">대기중</button></td>\
                                            </tr>\
                                        <tr>\
                                            <td>3</td>\
                                            <td>심상일</td>\
                                            <td>의사</td>\
                                            <td>전북대병원</td>\
                                            <td><button type="button" class="btn btn-warning disabled">대기중</button></td>\
                                            </tr>\
                                        <tr>\
                                            <td>4</td>\
                                            <td>김우성</td>\
                                            <td>의사</td>\
                                            <td>전북대병원</td>\
                                            <td><button type="button" class="btn btn-success">협약완료</button></td>\
                                            </tr>\
                                    </tbody>\
                                </table>\
                            </div>\
                            <!-- table-responsive -->\
                </div>\
                \
            </div>\
    </div>\
    <!-- /.panel-body -->\
</div>\
<!-- /.panel -->\
';
 
return result;
}
 
function tablequery(){
    var result =
                                        '<table class="table table-striped">\
                                        <thead>\
                                            <tr>\
                                                <th><input id=ch1 type="checkbox" value=""></th>\
                                                <th>#</th>\
                                                <th>Title</th>\
                                                <th>Version</th>\
                                                <th>생성자</th>\
                                                <th>생성일</th>\
                                                <th>마지막 수정자</th>\
                                                <th>마지막 수정일</th>\
                                                <th>마지막 실행일</th>\
                                                <th>상태</th>\
                                                <th></th>\
                                            </tr>\
                                        </thead>\
                                        <tbody>\
                                            <tr>\
                                                <td><input id=ch1 type="checkbox" value=""></td>\
                                                <td>1</td>\
                                                <td>Tenofovir 복용환자</td>\
                                                <td>1.0</td>\
                                                <td>정상운</td>\
                                                <td>2018.04.01 13:31:30</td>\
                                                <td>김민걸</td>\
                                                <td>2018.04.30 14:39:30</td>\
                                                <td>2018.05.02 10:39:30</td>\
                                                <td>실행완료</td>\
                                                <td>\
                                                        <button type="button" class="btn btn-info btn-sm" >Edit</button>\
                                                        <button type="button" class="btn btn-info btn-sm">Excute</button>\
                                                        <button type="button" class="btn btn-info btn-sm">Result</button>\
                                                </td>\
                                            </tr>\
                                            <tr>\
                                                <td><input id=ch1 type="checkbox" value=""></td>\
                                                <td>2</td>\
                                                <td>Tenofovir 복용환자2</td>\
                                                <td>1.1</td>\
                                                <td>김민지</td>\
                                                <td>2018.04.01 13:31:30</td>\
                                                <td>김민걸</td>\
                                                <td>2018.04.30 14:39:30</td>\
                                                <td>2018.05.02 10:39:30</td>\
                                                <td>처리중</td>\
                                                <td>\
                                                        <button type="button" class="btn btn-info btn-sm">Edit</button>\
                                                        <button type="button" class="btn btn-info btn-sm">Excute</button>\
                                                </td>\
                                            </tr>\
                                            <tr>\
                                                <td><input id=ch1 type="checkbox" value=""></td>\
                                                <td>3</td>\
                                                <td>Entecavir 복용환자</td>\
                                                <td>1.1</td>\
                                                <td>심상일</td>\
                                                <td>2018.04.01 13:31:30</td>\
                                                <td>정상운</td>\
                                                <td>-</td>\
                                                <td>2018.05.02 10:39:30</td>\
                                                <td>실행완료</td>\
                                                <td>\
                                                        <button type="button" class="btn btn-info btn-sm">Edit</button>\
                                                        <button type="button" class="btn btn-info btn-sm">Excute</button>\
                                                        <button type="button" class="btn btn-info btn-sm">Result</button>\
                                                </td>\
                                            </tr>\
                                            <tr>\
                                                <td><input id=ch1 type="checkbox" value=""></td>\
                                                <td>4</td>\
                                                <td>Tenofovir & Entecavir 복용환자</td>\
                                                <td>0.1</td>\
                                                <td>김민걸</td>\
                                                <td>2018.04.01 13:31:30</td>\
                                                <td>김민걸</td>\
                                                <td>2018.04.30 14:39:30</td>\
                                                <td>2018.05.02 10:39:30</td>\
                                                <td>처리중</td>\
                                                <td>\
                                                        <button type="button" class="btn btn-info btn-sm">Edit</button>\
                                                        <button type="button" class="btn btn-info btn-sm">Excute</button>\
                                                </td>\
                                            </tr>\
                                        </tbody>\
                                    </table>\
                                    '
return result ;
}
 
 
function iconChange(a){
    if(a==1){
        return '<i  class="fa fa-arrow-circle-down fa-fw"></i>';
    }else{
        return '<i  class="fa fa-arrow-circle-up fa-fw"></i>';
    }
}
 
function test(){
    var buf=
'\
<div class="panel-body" style="padding:0px">\
        <div class="table-responsive">\
            <table class="table table-striped">\
                <thead>\
                    <tr>\
                        <th></th>\
                        <th>Criteria</th>\
                        <th>Attribute</th>\
                        <th>\
                        Value\
                        <span class="pull-right">\
                            <button type="button" class="btn btn-default btn-xs" onClick="addTermSet()">조건추가</button>\
                        </span>\
                        </th>\
                    </tr>\
                </thead>\
                <tbody id="termSet">\
                    <tr>\
                    <td><span class="pull-left"><i class="glyphicon glyphicon-trash fa-fw"></i></span></td>\
                        <td>\
                            <select id="criteria" name="dataTables-example_length" aria-controls="dataTables-example" class="form-control input-sm" onChange=chageLangSelect()>\
                                <option value="1">Person</option>\
                                <option value="2">Condition_Occurrence</option>\
                                <option value="3">Maserment</option>\
                            </select>\
                        </td>\
                        <td>\
                            <select id="attribute" name="dataTables-example_length" aria-controls="dataTables-example" class="form-control input-sm">\
                                <option value="1">Birth</option>\
                                <option value="2">Gender</option>\
                            </select>\
                        </td>\
                        <!-- <td>\
                            <select name="dataTables-example_length" aria-controls="dataTables-example" class="form-control input-sm">\
                                <option value="<">Less Than</option>\
                                <option value="<=">Less or Equal To</option>\
                                <option value="=">Equal To</option>\
                                <option value=">">Greater Than</option>\
                                <option value=">=">Greater or Equal To</option>\
                            </select>\
                        </td> -->\
                        <td>\
                            <input type="text" id="birth" value="1998">\
                        </td>\
                    </tr>\
                </tbody>\
            </table>\
        </div>\
        <!-- /.table-responsive -->\
    </div>\
';
return buf;
}

function test1(){
    var buf=
'\
<div class="panel-body" style="padding:0px">\
    <div class="table-responsive">\
        <table class="table table-striped">\
            <thead>\
                <tr>\
                    <th>Criteria</th>\
                    <th>Attribute</th>\
                    <th>\
                    Value\
                    <span class="pull-right">\
                        <button type="button" class="btn btn-default btn-xs" onClick="addTermSet()">조건추가</button>\
                    </span>\
                    </th>\
                </tr>\
            </thead>\
            <tbody id="termSet">\
                <tr>\
                    <td>\
                        <select id="criteria" name="dataTables-example_length" aria-controls="dataTables-example" class="form-control input-sm" onChange=chageLangSelect() >\
                            <option value="1">Condition_Occurrence</option>\
                        </select>\
                    </td>\
                    <td>\
                        <select id="attribute" name="dataTables-example_length" aria-controls="dataTables-example" class="form-control input-sm">\
                            <option value="1">condition_occurrence_id</option>\
                        </select>\
                    </td>\
                    <!-- <td>\
                        <select name="dataTables-example_length" aria-controls="dataTables-example" class="form-control input-sm">\
                            <option value="<">Less Than</option>\
                            <option value="<=">Less or Equal To</option>\
                            <option value="=">Equal To</option>\
                            <option value=">">Greater Than</option>\
                            <option value=">=">Greater or Equal To</option>\
                        </select>\
                    </td> -->\
                    <td>\
                        <input type="text" id="co_id" value="19079524">\
                    </td>\
                </tr>\
            </tbody>\
        </table>\
    </div>\
    <!-- /.table-responsive -->\
</div>\
';
return buf;
}

function test2(){
    var buf=
'\
<div class="panel-body" style="padding:0px">\
    <div class="table-responsive">\
        <table class="table table-striped">\
            <thead>\
                <tr>\
                    <th>Criteria</th>\
                    <th>Attribute</th>\
                    <th>\
                    Value\
                    <span class="pull-right">\
                        <button type="button" class="btn btn-default btn-xs" onClick="addTermSet()">조건추가</button>\
                    </span>\
                    </th>\
                </tr>\
            </thead>\
            <tbody id="termSet">\
                <tr>\
                    <td>\
                        <select id="criteria" name="dataTables-example_length" aria-controls="dataTables-example" class="form-control input-sm" onChange=chageLangSelect() >\
                            <option value="1">Condition_Occurrence</option>\
                        </select>\
                    </td>\
                    <td>\
                        <select id="attribute" name="dataTables-example_length" aria-controls="dataTables-example" class="form-control input-sm">\
                            <option value="1">condition_occurrence_id</option>\
                        </select>\
                    </td>\
                    <!-- <td>\
                        <select name="dataTables-example_length" aria-controls="dataTables-example" class="form-control input-sm">\
                            <option value="<">Less Than</option>\
                            <option value="<=">Less or Equal To</option>\
                            <option value="=">Equal To</option>\
                            <option value=">">Greater Than</option>\
                            <option value=">=">Greater or Equal To</option>\
                        </select>\
                    </td> -->\
                    <td>\
                        <input id="dco_id" type="text" value="42903049">\
                    </td>\
                </tr>\
            </tbody>\
        </table>\
    </div>\
    <!-- /.table-responsive -->\
</div>\
';
return buf;
}


function addTermSet(){
    var buf = document.getElementById("termSet").outerHTML;

    buf += 
'<tr>\
    <td>\
        <select id="criteria" name="dataTables-example_length" aria-controls="dataTables-example" class="form-control input-sm" onChange=chageLangSelect()>\
            <option value="1">Person</option>\
            <option value="2">Condition_Occurrence</option>\
            <option value="3">Maserment</option>\
        </select>\
    </td>\
    <td>\
        <select id="attribute" name="dataTables-example_length" aria-controls="dataTables-example" class="form-control input-sm">\
            <option value="1">Birth</option>\
            <option value="2">Gender</option>\
        </select>\
    </td>\
    <!-- <td>\
        <select name="dataTables-example_length" aria-controls="dataTables-example" class="form-control input-sm">\
            <option value="<">Less Than</option>\
            <option value="<=">Less or Equal To</option>\
            <option value="=">Equal To</option>\
            <option value=">">Greater Than</option>\
            <option value=">=">Greater or Equal To</option>\
        </select>\
    </td> -->\
    <td>\
        <input type="text" id="value>">\
    </td>\
</tr>';
    return document.getElementById("termSet").innerHTML = buf;

}
var pp;
var d1 = 0;
var d2 = 0;
function excutesql(){
    pie1 = document.getElementById("birth").value;
    pie2 = document.getElementById("co_id").value;
    pie3 = document.getElementById("dco_id").value;
    
    alert("검색시작\n입력값:"+pie1+", "+pie2+", "+pie3);

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange=function() {
    if (this.readyState == 4 && this.status == 200) {
    //   document.getElementById("demo").innerHTML = this.responseText;
    var arr = this.responseText;
    var arr1 = arr.split(",");

    alert("검색이 완료되었습니다. Result버튼을 눌러주세요. \n출력 값:"+arr1+", len:"+arr1.length);
    }

    d1 = 1;
    d2 = 1;
    $(function() {
        var data = [{
            label: "여자",
            data: d1
        }, {
            label: "남자",
            data: d2
        }];
    document.getElementById("patientNUM").innerHTML = d1+d2
    document.getElementById("resultHead").innerHTML="남자 수: "+d2+"명, 여자 수: "+d1+"명"
    var plotObj = $.plot($("#flot-pie-chart1"), data, {
        series: {
            pie: {
                show: true
            }
        },
        grid: {
            hoverable: true
        },
        tooltip: true,
        tooltipOpts: {
            content: "%p.0%, %s", // show percentages, rounding to 2 decimal places
            shifts: {
                x: 20,
                y: 0
            },
            defaultTheme: false
        }
        }); 
    
    });
  };
  xhttp.open("GET", "./results.jsp?birth="+pie1+"&co_id="+pie2+"&dco_id="+pie3+"");
  xhttp.send();
}

