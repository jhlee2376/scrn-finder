// query

var dateFormat = require('dateformat');
function Query(id, title, name){
    
    this.query_id =id;
    this.query_title=title;
    this.query_create_date = dateFromat(new Date(),"yyyy-dddd-mmmm,h:MM;SS");
    this.query_modify_date = '-';
    this.query_exe_date = '-';
    this.query_status =1;
    this.query_creator =name;
    this.query_last_editor='-'
} 


function makeQuery(id, title, name){
   var obj = {
    query_id            :   id,
    query_title         :   title,
    query_create_date   : new Date(),
    query_modify_date   : '-',
    query_exe_date      : '-',
    query_status        :   1,
    query_creator       :  name,
    query_last_editor   : '-'
    }
    return obj;
}
    

//{"query_id":1,"study_id":1,"title":"나이 조건 검색","criteriaSet":[{"table":"Person","field":"birth","condition":3,"value":"1900"},{"table":"Person","field":"birth","condition":3,"value":"2500"}]}
//조건
// Class Criteria{
//     String  table;
//     String  field;
//     int     condition;
//     String  value;
// }


function Criteria_detail(id, table, field, condition, value, criteria_id){
    var obj = {
        criteria_detail_id          :   id,
        criteria_detail_table       :   table,
        criteria_detail_field       :   field,
        criteria_detail_condition   :   condition, 
        criteria_detail_value       :   value,
        criteria_id                 :   criteria_id
    }
    return obj;
}

function Criteria(id,title,state){
    var obj = {
        criteria_id             :    id,
        criteria_title          :    title,
        criteria_state          :    state,
        criteria_detail_set   :    []
    }
    return obj;
}

function makeCriteria(criteria_id, query_id, title, table, attribute, condition, value, include){
    this.criteria_id    = criteria_id;
    this.query_id       = query_id;
    this.title          = title;
    this.table          = table;
    this.attribute      = attribute;
    this.condition      = condition;
    this.value          = value;
    this.include        = include // 1: 선정, 2: 비선정;
}

//CriteriaSet
function makeCriteriaSet(){
    
}



