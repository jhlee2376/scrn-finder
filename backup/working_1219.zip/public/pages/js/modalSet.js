var cdm = {"table":[{"tableName":"person","fieldSet":["person_id","condition_concept_id","condition_start_date","condition_end_date","condition_type_concept_id","stop_reason","provider_id","visit_occurrence_id","condition_source_value","condition_source_concept_id"]},{"tableName":"specimen","fieldSet":["person_id","condition_concept_id","condition_start_date","condition_end_date","condition_type_concept_id","stop_reason","provider_id","visit_occurrence_id","condition_source_value","condition_source_concept_id"]},{"tableName":"visit_occurence","fieldSet":["person_id","condition_concept_id","condition_start_date","condition_end_date","condition_type_concept_id","stop_reason","provider_id","visit_occurrence_id","condition_source_value","condition_source_concept_id"]},{"tableName":"procedure_occurrence","fieldSet":["person_id","condition_concept_id","condition_start_date","condition_end_date","condition_type_concept_id","stop_reason","provider_id","visit_occurrence_id","condition_source_value","condition_source_concept_id"]},{"tableName":"condition_occrrence","fieldSet":["person_id","condition_concept_id","condition_start_date","condition_end_date","condition_type_concept_id","stop_reason","provider_id","visit_occurrence_id","condition_source_value","condition_source_concept_id"]}]}
cdm = cdm.table;
var logcon = 0;
function makeModal(){
    //alert("makeModal");
    var divModalfade = document.createElement("div");
    divModalfade.setAttribute("class", "modal fade modal-lg");
    divModalfade.setAttribute("id", "createQuery");
    divModalfade.setAttribute("tabindex", "-1");
    divModalfade.setAttribute("role", "dialog");
    divModalfade.setAttribute("aria-labelledby", "myModalLabel");
    divModalfade.setAttribute("aria-hidden", "true");
    
//
    var divModalDialog = document.createElement("div");
    divModalDialog.setAttribute("class","modal-dialog");
    divModalfade.appendChild(divModalDialog);
//
    var divModalContent = document.createElement("div");
    divModalContent.setAttribute("class","modal-content");
    divModalDialog.appendChild(divModalContent);
//    
    var divModalHeader = document.createElement("div");
    divModalHeader.setAttribute("class","modal-header"); 

    var divModalHeaderButton = document.createElement("BUTTON");
    divModalHeaderButton.setAttribute("type","button");
    divModalHeaderButton.setAttribute("class","close");
    divModalHeaderButton.setAttribute("data-dismiss","modal");
    divModalHeaderButton.setAttribute("aria-label","Close");
    
    var divModalHeaderButtonSpan = document.createElement("SPAN");
    divModalHeaderButtonSpan.setAttribute("aria-hidden","true");
    divModalHeaderButtonSpan.innerHTML="&times;"
    divModalHeaderButton.appendChild(divModalHeaderButtonSpan);

    var divModalHeaderh4 = document.createElement("H4");
    divModalHeaderh4.setAttribute("class","modal-title");
    divModalHeaderh4.setAttribute("id","myModalLabel");
    divModalHeaderh4.innerHTML="Query 생성";
    // 연결
    divModalHeader.appendChild(divModalHeaderButton);
    divModalHeader.appendChild(divModalHeaderh4);
    divModalContent.appendChild(divModalHeader);
//
    var divModalBody = document.createElement("div");
    divModalBody.setAttribute("class","modal-body");
    var divModalBodyForm = document.createElement("FORM");
    var divModalBodyFormDiv = document.createElement("div");
    divModalBodyFormDiv.setAttribute("class","form-group");
    var divModalBodyFormDivLabe = document.createElement("Label");
    divModalBodyFormDivLabe.setAttribute("for","recipient-name");
    divModalBodyFormDivLabe.setAttribute("class","control-label");
    divModalBodyFormDivLabe.innerHTML="제목";
    var divModalBodyFormDivInput = document.createElement("INPUT");
    divModalBodyFormDivInput.setAttribute("type","text");
    divModalBodyFormDivInput.setAttribute("class","form-control");
    divModalBodyFormDivInput.setAttribute("id","createQueryInput");
    // divModalbody-form-div-label,input
    divModalBodyFormDiv.appendChild(divModalBodyFormDivLabe);
    divModalBodyFormDiv.appendChild(divModalBodyFormDivInput);
    divModalBodyForm.appendChild(divModalBodyFormDiv);
    divModalBody.appendChild(divModalBodyForm);
    divModalContent.appendChild(divModalBody);
//
    var divModalFooter = document.createElement("div");
    divModalFooter.setAttribute("class","modal-footer");
    var divModalFooterButtonClose = document.createElement("BUTTON");
    divModalFooterButtonClose.setAttribute("type","button");
    divModalFooterButtonClose.setAttribute("class","btn btn-default");
    divModalFooterButtonClose.setAttribute("data-dismiss","modal");
    divModalFooterButtonClose.innerHTML="Close";
    var divModalFooterButtonSave = document.createElement("BUTTON");
    divModalFooterButtonSave.setAttribute("type","button");
    divModalFooterButtonSave.setAttribute("class","btn btn-primary");
    divModalFooterButtonSave.setAttribute("data-dismiss","modal");
    divModalFooterButtonSave.setAttribute("onclick","createQuery(document.getElementById('createQueryInput').value,user.name)");
    divModalFooterButtonSave.innerHTML="Save chages";
    //divModalFooter-botton, botton
    divModalFooter.appendChild(divModalFooterButtonClose);
    divModalFooter.appendChild(divModalFooterButtonSave);
    divModalContent.appendChild(divModalFooter);
    //divModalFade-divModalDialog-divModalContent
    document.getElementById("modalSet").appendChild(divModalfade);
}


/*
Class Query{ 
    int     sutyd_id; 
    int     query_id;
    String  query_title;
    Date    query_create_date;
    String  query_creator;
    Date    query_exe_date;
    String  query_last_editor;
    Date    query_modify_date;
    int     query_state;
    List    CriteriaSet[];
}
Class Criteria{
    String  table;
    String  field;
    int     condition;
    String  value;
}

QuerySet[index].CriteriaSet[j]
*/
//////////////////// Queyr 페이지 관련 모달 Start //////////////////////////
// QueryEditModal

  var criteriaSet = [];
  var queryIndex = 0;
//console.log("최초선언: "+criteriaSet);



//////////////////////// 버튼 이벤트 관련
// Edit 버튼 클릭 시 이벤트 
function edit_getCriteriaSet(index){
    //console.log("Start: edit_getCriteriaSet()");

    //getCriteriaSet(index)
    // queryTitle 제목 
    // 쿼리
    //document.getElementById('queryTitle').innerHTML=querySet[index].query_title;
    //console.log(querySet[index].query_title);
   // $("addSelect").onclick()="ii();"
   queryIndex = index
    $("#addSelect").attr('onclick','addMid('+1+')');
    $("#addDisSelect").attr('onclick','addMid('+2+')');
    $("#queryTitle").val(querySet[index-1].query_title);
    // CriteriaSet 가져오기. 
    // Criteria_title 불러오고 Criteria_id 값을 이용하여 Criteria_detail를 불러온다.
    //console.log("getCriteriaSet 호출");
    var subCriteriaSet = getCriteriaSet(index);
        //console.log("getCriteriaSet 끝");
    // 뷰함수 호출.
    //console.log("End: edit_getCriteriaSet() ");
}

//버튼 이벤트 테스트
function test(index){
    alert("Add new Criteria to CreteriaSet"+index);
}

function addMid(state){
    alert("addMid")
    var id=1;
    //id값 넣기.
    for(var i=0;i<criteriaSet.length;i++){
        if(criteriaSet[i].criteria_state==state){
            if(criteriaSet[i].criteria_id>id){
                id = criteriaSet[i].criteria_id;
            }
        }
    }
    id =id+1
    criteriaSet.push(Criteria(id,"제목없음",state));
    if(state==1){
        document.getElementById("includecondition").innerHTML= "";
        document.getElementById("includecondition").appendChild(viewSelectionMiddleCondition(criteriaSet,state));
    }else{
        document.getElementById("notIncludecondition").innerHTML= "";
        document.getElementById("notIncludecondition").appendChild(viewSelectionMiddleCondition(criteriaSet,state));
    }
    
}



//서버에 CriteriaSet 요청하기.
function getCriteriaSet(queryIndex){

    getCriteriaQuery(queryIndex);
    //return queryIndex;
}

function viewCriteriaBoxSmall(middleIndex, location){
    //locaion==1 선정, 0 비 선정


}

//QueryEditModal//////////////////////////////////////

/////////////////////////////////////////////////////////
// Criteria_title
function makeCriteria_title(name){

}


//////////////////////////////////////////////////////////////////////////////////
// Criteria
/////////////////////////////////////////////////////////;
//  start_Criteria_Big_
//  queryBox_Big_View()

function queryEditModal(){
    
    //modal fade
        var divModalfade = document.createElement("div");
        document.getElementById("modalSet").appendChild(divModalfade);
        divModalfade.setAttribute("class", "modal fade");
        divModalfade.setAttribute("id", "queryEdit");
        divModalfade.setAttribute("tabindex", "-1");
        divModalfade.setAttribute("role", "dialog");
        divModalfade.setAttribute("aria-labelledby", "myModalLabel");
        divModalfade.setAttribute("aria-hidden", "true");
    
    //modal fade - modal-dialog
        var divModalDialog = document.createElement("div");
        divModalDialog.setAttribute("class","modal-dialog modal-lg");
        divModalfade.appendChild(divModalDialog);
    
    //modal fade - modal-dialog - modal-content
        var divModalContent = document.createElement("div");
        divModalContent.setAttribute("class","modal-content");
        divModalDialog.appendChild(divModalContent);
    
    //modal fade - modal-dialog - modal-content - modal-header
        var divModalHeader = document.createElement("div");
        divModalHeader.setAttribute("class","modal-header");
        divModalContent.appendChild(divModalHeader);
    // modal-header - button
        var divModalHeaderButton = document.createElement("BUTTON");  // 닫기 버튼
        divModalHeader.appendChild(divModalHeaderButton);
        divModalHeaderButton.setAttribute("type","button");
        divModalHeaderButton.setAttribute("class","close");
        divModalHeaderButton.setAttribute("data-dismiss","modal");
        divModalHeaderButton.setAttribute("aria-label","Close");
        
        var divModalHeaderButtonSpan = document.createElement("SPAN");
        divModalHeaderButton.appendChild(divModalHeaderButtonSpan);
        divModalHeaderButtonSpan.setAttribute("aria-hidden","true");
        divModalHeaderButtonSpan.innerHTML="&times;"
    
        var divModalHeaderh4 = document.createElement("H4");
        divModalHeader.appendChild(divModalHeaderh4);
        divModalHeaderh4.setAttribute("class","modal-title");
        divModalHeaderh4.setAttribute("id","myModalLabel");
        divModalHeaderh4.innerHTML="Query 조건 편집";
    
        //modal-body
        var divModalBody = document.createElement("div");
        divModalBody.setAttribute("class","modal-body");
        divModalContent.appendChild(divModalBody);
    
        //modal-body > form-group
        var divModalBodyForm = document.createElement("FORM");
        divModalBody.appendChild(divModalBodyForm);
    
        var divModalBodyFormDiv = document.createElement("div");
        divModalBodyFormDiv.setAttribute("class","form-group");
        divModalBodyForm.appendChild(divModalBodyFormDiv);
    
        //modal-body > form-group > label
        var divModalBodyFormDivLabel = document.createElement("Label");
        divModalBodyFormDiv.appendChild(divModalBodyFormDivLabel);
        divModalBodyFormDivLabel.setAttribute("for","recipient-name");
        divModalBodyFormDivLabel.setAttribute("class","control-label");
        divModalBodyFormDivLabel.innerHTML="제목";
        //modal-body > form-group > input
        var divModalBodyFormDivInput = document.createElement("INPUT");
        divModalBodyFormDiv.appendChild(divModalBodyFormDivInput);
        divModalBodyFormDivInput.setAttribute("type","text");
        divModalBodyFormDivInput.setAttribute("class","form-control");
        divModalBodyFormDivInput.setAttribute("id","queryTitle");
    
        //쿼리 조정
        var divModalBodyFormDivQueryCon = document.createElement("div");
        divModalBodyFormDivQueryCon.setAttribute("class","form-group");
        divModalBodyForm.appendChild(divModalBodyFormDivQueryCon);
    
        var divlabel = document.createElement("label");
        divModalBodyFormDivQueryCon.appendChild(divlabel);
        divlabel.setAttribute=("for","message-text");
        divlabel.setAttribute=("class","control-label");
        divlabel.innerHTML="쿼리 조건 설정";
    
        var divrow = document.createElement("div");
        divrow.setAttribute("class","row");
        divModalBodyFormDivQueryCon.appendChild(divrow);
    
        var div_col_lg_6 = document.createElement("div");
        div_col_lg_6.setAttribute("class","col-lg-6");
        divrow.appendChild(div_col_lg_6);
                
        var panel_panel_info = document.createElement("div");
        panel_panel_info.setAttribute("class","panel panel-info");
        div_col_lg_6.appendChild(panel_panel_info);
    
        var panel_heading = document.createElement("div");
        panel_heading.setAttribute("class","panel-heading");
        panel_heading.setAttribute("id","test1");
        panel_heading.innerHTML="선정조건";
        panel_panel_info.appendChild(panel_heading);
    
        var span = document.createElement("span");
        span.setAttribute("class","pull-right");
        panel_heading.appendChild(span);
    
        var span_button= document.createElement("button");
        span_button.setAttribute("id","queryEditSelectButton")
        span_button.setAttribute("type","button");
        span_button.setAttribute("class","btn btn-primary btn-xs");
        span_button.setAttribute("id","addSelect");
        //span_button.setAttribute("onclick","ppaaaaaaaa()");
        span_button.innerHTML="선정조건 추가하기";
        span.appendChild(span_button);
        
        var panel_body = document.createElement("div");
        panel_body.setAttribute("class","panel-body");
        panel_body.setAttribute("id","includecondition");
        panel_body.setAttribute("style","padding:5px;");
        //panel_body.innerHTML="1";
        panel_panel_info.appendChild(panel_body);
                
    //제외조건
    
        var div_col_lg_6_2 = document.createElement("div");
        div_col_lg_6_2.setAttribute("class","col-lg-6");
        divrow.appendChild(div_col_lg_6_2);
        
        var div_panl_panel_danger = document.createElement("div");
        div_panl_panel_danger.setAttribute("class","panel panel-danger");
        div_col_lg_6_2.appendChild(div_panl_panel_danger);
    
        var panel_heading2 = document.createElement("div");
        panel_heading2.setAttribute("class","panel-heading");
        panel_heading2.innerHTML="제외조건";
        div_panl_panel_danger.appendChild(panel_heading2);
    
        var span2 = document.createElement("span");
        span2.setAttribute("class","pull-right");
        panel_heading2.appendChild(span2);
    
        var span_button2= document.createElement("button");
        span_button2.setAttribute("id","queryEditDisSelectButton")
        span_button2.setAttribute("type","button");
        span_button2.setAttribute("class","btn btn-danger btn-xs");
        span_button2.setAttribute("id","addDisSelect");
        span_button2.innerHTML="제외조건 추가하기";
        span_button2.setAttribute("onclick","addQuery()");
        span2.appendChild(span_button2);
    
        var panel_body2 = document.createElement("div");
        panel_body2.setAttribute("class","panel-body");
        panel_body2.setAttribute("id","notIncludecondition");
        panel_body2.setAttribute("style","padding:5px;");
        div_panl_panel_danger.appendChild(panel_body2);
    
        var script_selectcontion2 = document.createElement("script");
        //script_selectcontion2.innerHTML=selectCondition();
        panel_body2.appendChild(script_selectcontion2);
    
        // divModalbody-form-div-label,input
    
    //
        var divModalFooter = document.createElement("div");
        divModalFooter.setAttribute("class","modal-footer");
        var divModalFooterButtonClose = document.createElement("BUTTON");
        divModalFooterButtonClose.setAttribute("type","button");
        divModalFooterButtonClose.setAttribute("class","btn btn-default");
        divModalFooterButtonClose.setAttribute("data-dismiss","modal");
        divModalFooterButtonClose.innerHTML="Close";
        var divModalFooterButtonSave = document.createElement("BUTTON");
        divModalFooterButtonSave.setAttribute("type","button");
        divModalFooterButtonSave.setAttribute("class","btn btn-primary");
        divModalFooterButtonSave.setAttribute("data-dismiss","modal");
        divModalFooterButtonSave.setAttribute("onclick","save_CriteriaSet($('.midTitle'),$('.criteria'))");
        divModalFooterButtonSave.innerHTML="Save chages";
        //divModalFooter-botton, botton
        divModalFooter.appendChild(divModalFooterButtonClose);
        divModalFooter.appendChild(divModalFooterButtonSave);
        divModalContent.appendChild(divModalFooter);
        //divModalFade-divModalDialog-divModalContent
        
    }

    function save_CriteriaSet(midTitleSet, smallSet){
        alert("save_CriteriaSet");
        logP(midTitleSet,logcon);
        logP(smallSet,logcon)

        //1. midIndex넣고, 제목넣기.
        //2. 디테일 Array 넣기

        var newCriteriaSet = [];

        var titleList =[];
        var buf ="";
        //제목 넣기.
        for(var i=0;i<midTitleSet.length;i++){
            buf = midTitleSet[i].getAttribute("id").split("_");
            newCriteriaSet.push(Criteria(buf[1],midTitleSet[i].outerText,buf[2]));
        }
        
        var mid, state, small;
        for(var i=0;i<smallSet.length;i++){
            buf = smallSet[i].getAttribute("id").split("_");
            
            mid = buf[1];
            small = buf[2];
            state = buf[3];

            table       = smallSet[i].children[1].children[0].value;
            field       = smallSet[i].children[2].children[0].value;
            condition   = smallSet[i].children[3].children[0].value;
            value       = smallSet[i].children[4].children[0].value; 

            for(var j=0;j<newCriteriaSet.length;j++){
                if(newCriteriaSet[j].criteria_id ==mid && newCriteriaSet[j].criteria_state == state){
                    newCriteriaSet[j].criteria_detail_set.push(Criteria_detail(small,table,field,condition,value,mid));
                }
            }
        }

        logP(newCriteriaSet,logcon);
        criteriaSet = newCriteriaSet;
    }
//--queryBox_Big_Add()

//  end_Criteria_Big_

//  start_Criteria_Mid_
/// --queryBox_mid_View()
/// 선정 및 비선정 중간 제외조건 넣기 모달.
function viewSelectionMiddleCondition(criteriaSet1,con){
    //console.log("viewSelectionMiddleCondition 실행");
    //selectCondition 안에 들어감 
    var panel_body = document.createElement("div");
    
    panel_body.setAttribute("class","panel-body");
    panel_body.setAttribute("style","padding:0px;");

    var panel_group = document.createElement("div");
    panel_body.appendChild(panel_group);
    panel_group.setAttribute("class","panel-group");
    panel_group.setAttribute("id","accordion");
    var chk=0;
    for(var i=0;i<criteriaSet1.length;i++){
        if(criteriaSet1[i].criteria_state==con)
        {
            chk++;
            var panel_panel_default = document.createElement("div");
            panel_group.appendChild(panel_panel_default);
            panel_panel_default.setAttribute("class","panel panel-default");
            
            var panel_heading = document.createElement("div");
            panel_heading.setAttribute("class","panel-heading");
            panel_panel_default.appendChild(panel_heading);
    
            var heading_h4 = document.createElement("h4");
            heading_h4.setAttribute("class","panel-title");
            heading_h4.setAttribute("id","mid_Title_"+criteriaSet[i].criteria_id+"_"+criteriaSet[i].criteria_state);



            
            panel_heading.appendChild(heading_h4);
    
            var h4_a = document.createElement("a");
            heading_h4.appendChild(h4_a);
            h4_a.setAttribute("id","midIndex_"+criteriaSet[i].criteria_id+"_"+criteriaSet[i].criteria_state);
            h4_a.setAttribute("data-toggle","collapse");
            h4_a.setAttribute("data-parent","#accordion");
            h4_a.setAttribute("class","midTitle");
            
            if(con==1){
                chk = "select"+criteriaSet[i].criteria_id;
            }else{
               chk = "notSelect"+criteriaSet[i].criteria_id;
            }
            h4_a.setAttribute("href","#"+chk);
            //h4_a.setAttribute("onclick","pageChange("+chk+")");
            h4_a.innerHTML=criteriaSet1[i].criteria_title;
    
            var h4_i_change = document.createElement("i");
            heading_h4.appendChild(h4_i_change);
            h4_i_change.setAttribute("class","fa fa-pencil fa-fw");
            //midChange
            //h4_i_change.setAttribute("onclick","midTitlechange("+criteriaSet[i].criteria_id+","+criteriaSet[i].criteria_state+")");
            h4_i_change.setAttribute("onclick","updateTitle("+criteriaSet[i].criteria_id+","+criteriaSet[i].criteria_state+")");
    
            var h4_i_remove = document.createElement("i");
            heading_h4.appendChild(h4_i_remove);
            h4_i_remove.setAttribute("class","glyphicon glyphicon-trash fa-fw");
            h4_i_remove.setAttribute("onclick","remove_midTitle("+criteriaSet[i].criteria_id+","+criteriaSet[i].criteria_state+")");
    
            var h4_spal = document.createElement("span");
            heading_h4.appendChild(h4_spal);
            h4_spal.setAttribute("class","pull-right");
    
            var h4_spal_i = document.createElement("i");
            h4_spal.appendChild(h4_spal_i);
            h4_spal_i.setAttribute("class","fa fa-arrow-circle-down fa-fw");

            //detail criteria 가 들어갈 부분
            var panel_collapse_collapse_in = document.createElement("div");
            panel_panel_default.appendChild(panel_collapse_collapse_in);
            panel_collapse_collapse_in.setAttribute("id",chk);
            panel_collapse_collapse_in.setAttribute("class","panel-collapse collapse in");

            var panel_body_collapse = document.createElement("div");
            panel_collapse_collapse_in.appendChild(panel_body_collapse);
            panel_body_collapse.setAttribute("class","panel-body");
            panel_body_collapse.setAttribute("style","padding:0px;padding-left: 5px;");
            panel_body_collapse.setAttribute("id","progroup_"+chk);
            
            var panel_body_panel_body_collase = document.createElement("div");
            panel_body_collapse.appendChild(panel_body_panel_body_collase);
            panel_body_panel_body_collase.setAttribute("class","panel-body");
            panel_body_panel_body_collase.setAttribute("style","padding:0px");
            panel_body_panel_body_collase.appendChild(queryBoxSmall_view(criteriaSet[i].criteria_id,criteriaSet[i].criteria_detail_set, criteriaSet[i].criteria_state));
        }
        
    }
    //console.log("viewSelectionMiddleCondition 끝");
    return panel_body
}

function remove_midTitle(criteria_id, state){
    alert("remove_midTitle");
    var delIdx =0;
    for(var i=0;i<criteriaSet.length;i++)
    {
        if(criteriaSet[i].criteria_id==criteria_id&&criteriaSet[i].criteria_state==state){
            delIdx=i;
        }
    }
    //console.log(delIdx);
    criteriaSet.splice(delIdx,1);

    if(state==1){
        document.getElementById("includecondition").innerHTML= "";
        document.getElementById("includecondition").appendChild(viewSelectionMiddleCondition(criteriaSet,state));
    }else{
        document.getElementById("notIncludecondition").innerHTML= "";
        document.getElementById("notIncludecondition").appendChild(viewSelectionMiddleCondition(criteriaSet,state));
    }
}
// 
//end_Criteria_Mid_



// START Criteria_SAMLL
function queryBoxSmall_view(midIndex, criteriaDetailSet, state){
    //console.log("Start queryBoxSmall_view "+criteriaDetailSet.length);
    //document.getElementById("progroup_select"+midIndex).innerHTML="";
    var panel_body = document.createElement("div");
    //document.getElementById("progroup_select").appendChild(panel_body);
    panel_body.setAttribute("class","panel-body");
    panel_body.setAttribute("style","padding:0px");

    var table_responsive = document.createElement("div");
    table_responsive.setAttribute("class","table-responsive");
    panel_body.appendChild(table_responsive);

    var table = document.createElement("table");
    table.setAttribute("class","table table-striped");
    table_responsive.appendChild(table);

    var thead = document.createElement("thead");``
    table.appendChild(thead);

    var tr_thead = document.createElement("tr");
    thead.appendChild(tr_thead);

    var th0_thead = document.createElement("th");
    tr_thead.appendChild(th0_thead);

    var th1_thead = document.createElement("th");
    th1_thead.innerHTML = "Table";
    tr_thead.appendChild(th1_thead);

    th1_thead = document.createElement("th");
    th1_thead.innerHTML = "Attribute";
    tr_thead.appendChild(th1_thead);

    var th2_thead = document.createElement("th");
    th2_thead.innerHTML="Condition";
    tr_thead.appendChild(th2_thead);
    
    var th3_thead = document.createElement("th");
    th3_thead.innerHTML = "value";
    tr_thead.appendChild(th3_thead);

    var th4_thead = document.createElement("th");

    var span_thead = document.createElement("span");
    span_thead.setAttribute("class","pull-right");
    th3_thead.appendChild(span_thead);
    //tr_thead.appendChild(th4_thead);

    var button_span = document.createElement("BUTTON");
    button_span.setAttribute("type","button");
    button_span.setAttribute("class","btn btn-default btn-xs")
    button_span.setAttribute("onClick","add_querySmall_detail("+midIndex+","+state+")");
    button_span.innerHTML="조건추가";
    span_thead.appendChild(button_span);

    var tbody = document.createElement("tbody");
    tbody.setAttribute("id","midTbody_"+midIndex+"_"+state);
    
    table.appendChild(tbody);

    //criteriaDetatil_set
    //td, select 변수 선언 및 기본 속성값 설정
    var td_tbody = document.createElement('td');

    var select_tbody = document.createElement("select");
    select_tbody.setAttribute("id","select_"+midIndex+"_");
    select_tbody.setAttribute("name","dataTables-example_length");
    select_tbody.setAttribute("aria-controls","dataTables-example");
    select_tbody.setAttribute("class","form-control");
    select_tbody.setAttribute("onChange","changeTableSelect()");
    
    var span_tbody = document.createElement("span");
    span_tbody.setAttribute("class","pull-left");
    var i_tbody = document.createElement("i");
    i_tbody.setAttribute("class","glyphicon glyphicon-trash fa-fw");
   
    span_tbody.appendChild(i_tbody);
    
    for(var i=0;i<criteriaDetailSet.length;i++){

        var tr_tbody = document.createElement("tr");
        tr_tbody.setAttribute("id","midSmallIndex_"+midIndex+"_"+i+"_"+state);
        tr_tbody.setAttribute("class","criteria");
        
        //휴지통
        i_tbody.setAttribute("onClick","del_small_detail("+midIndex+","+criteriaDetailSet[i].criteria_detail_id+","+state+")");
        td_tbody.innerHTML=span_tbody.outerHTML;
        tr_tbody.innerHTML+=td_tbody.outerHTML;
        
        //table
        select_tbody.setAttribute("id","table");
        select_tbody.innerHTML=option_cdm_tableList(cdm, criteriaDetailSet[i].criteria_detail_table);
        //select_tbody.value=2;
        
        td_tbody.innerHTML= select_tbody.outerHTML;
        tr_tbody.innerHTML+=td_tbody.outerHTML;

        //fileds
        select_tbody.setAttribute("id","fields");
        select_tbody.innerHTML=option_cdm_fiteldsList(cdm, criteriaDetailSet[i].criteria_detail_field)
        
        //console.log(i+", "+criteriaDetailSet[i].criteria_detail_filed);
        td_tbody.innerHTML=select_tbody.outerHTML;
        tr_tbody.innerHTML+=td_tbody.outerHTML;

        //con
        select_tbody.setAttribute("id","con");
        select_tbody.innerHTML=option_conditionList(criteriaDetailSet[i].criteria_detail_condition);
        //select_tbody.setAttribute("value",criteriaDetailSet[i].criteria_detail_condition);
        td_tbody.innerHTML=select_tbody.outerHTML;
        tr_tbody.innerHTML+=td_tbody.outerHTML;

        //value
        var input_tbody = document.createElement("input");
        input_tbody.setAttribute("id",'value_detail');
        input_tbody.setAttribute("value",criteriaDetailSet[i].criteria_detail_value);
        td_tbody.innerHTML=input_tbody.outerHTML;
        tr_tbody.innerHTML+=td_tbody.outerHTML;
        tbody.innerHTML += tr_tbody.outerHTML;
    }
       
        
   return panel_body;

}


function add_querySmall_detail(midIndex,state){
    alert("Add detail component to "+ midIndex+", "+state);
    //idx값 찾기.
    var idx=0;
    for(var i=0;i<criteriaSet.length;i++){
        if(criteriaSet[i].criteria_id==midIndex&&criteriaSet[i].criteria_state==state){
            idx =i;
        }
    }
    
    //detatil id 값 늘리기.
    var detailIdx =0;

    for(var i=0;i<criteriaSet[idx].criteria_detail_set.length;i++){
        if(criteriaSet[idx].criteria_detail_set[i].criteria_detail_id > detailIdx){
            detailIdx = criteriaSet[idx].criteria_detail_set[i].criteria_detail_id;
        }
    }
    detailIdx = detailIdx+1;

    criteriaSet[idx].criteria_detail_set.push(Criteria_detail(detailIdx,"1","1",1,"1900",idx));
    var out="";
    if(state==1){
        out = document.getElementById("progroup_select"+midIndex);
    }else{
        out = document.getElementById("progroup_notSelect"+midIndex);
    }
     
    out.innerHTML="";
    out.innerHTML = queryBoxSmall_view(midIndex, criteriaSet[idx].criteria_detail_set, state).outerHTML;


}

function option_cdm_tableList(cdm1, index){
    //console.log(index);
    var out ='';
    var opt = document.createElement("option");
    for(var i =0;i<cdm1.length;i++){
        opt.removeAttribute("selected");
        opt.setAttribute("value",i);
        if(i==index)
        {
            opt.setAttribute("selected","selected")
        }
        opt.innerHTML=cdm1[i].tableName;
        out += opt.outerHTML;
    }
    return out;
}

function option_cdm_fiteldsList(cdm1, index){
    //console.log(cdm)
    var out ='';
    var opt = document.createElement('option');
    for(var i=0;i<cdm1[index].fieldSet.length;i++){
        opt.setAttribute("value",i);
        opt.removeAttribute("selected");
        if(i==index){
            opt.setAttribute("selected","selected");
        }
        opt.innerHTML=cdm1[index].fieldSet[i];
        out += opt.outerHTML;
    }

    return out;
}

function option_conditionList(con){
    logP(con,logcon);
    var out;
    var opt= opt= document.createElement('option');;
    var conValue =["<","<=","=",">",">="];
    

    for(var i=0;i<5;i++){
        opt= document.createElement('option');
        opt.setAttribute("value",i+1);
        opt.innerHTML = conValue[i];

        if(i+1==con){
            opt.setAttribute("selected","selected");
        }
        out += opt.outerHTML;
    }
    

    return out;
}
//////////////////////////////////////////////////////////////////////////////////

function del_small_detail(midIndex, detail_id,state){
    alert("del_small_detail: "+midIndex+", "+detail_id);

    //idx값 찾기;
    var idx=0;

    for(var i=0;i<criteriaSet.length;i++){
        if(criteriaSet[i].criteria_id==midIndex&& criteriaSet[i].criteria_state==state){
            idx = i;
        }
    }

    //detail_id 위치값찾기.
    var didx=0;
    for(var i=0;i<criteriaSet[i].criteria_detail_set;i++){
        if(criteriaSet[idx].criteria_detail_set[i].criteria_detail_id==detail_id){
            didx = i;
        }
    }

    console.log(criteriaSet[idx].criteria_detail_set);
    criteriaSet[idx].criteria_detail_set.splice(didx,1);
    console.log(criteriaSet[idx].criteria_detail_set);

    var out="";
    if(state==1){
        out = document.getElementById("progroup_select"+midIndex);
    }else{
        out = document.getElementById("progroup_notSelect"+midIndex);
    }
     
    out.innerHTML="";
    out.innerHTML = queryBoxSmall_view(midIndex, criteriaSet[idx].criteria_detail_set, state).outerHTML;

}

function changeTableSelect(){
    alert("change");
}

function updateTitle(midIndex, state){
    alert(midIndex+", "+state);
    var a = document.getElementById("mid_Title_"+midIndex+"_"+state);
    
    var b = document.createElement("input");
    b.setAttribute("id",a.id);
    b.setAttribute("value",a.outerText);

    a.innerHTML ="";
    a.innerHTML = b.outerHTML;


    var b = document.createElement("i");
    b.setAttribute("class","glyphicon glyphicon-ok fa-fw");
    b.setAttribute("onClick","update_Title_ok("+midIndex+","+state+","+"mid_Title_"+midIndex+"_"+state+")");
    
    a.innerHTML += b.outerHTML;

    
}

function update_Title_ok(midIndex,state,output){
    var data = output[1];
    var con = state;
    alert(data);
    
    //idx
    var idx=0;

    for(var i=0;i<criteriaSet.length;i++){
        if(criteriaSet[i].criteria_id == midIndex &&criteriaSet[i].criteria_state==state ){
            idx = i;
        }
    }

    var i = idx;
    criteriaSet[i].criteria_title = data.value;

    var heading_h4 = document.getElementById(output[0].id);
    heading_h4.innerHTML="";
    var h4_a = document.createElement("a");
    heading_h4.appendChild(h4_a);
    h4_a.setAttribute("id","midIndex_"+criteriaSet[i].criteria_id+"_"+criteriaSet[i].criteria_state);
    h4_a.setAttribute("data-toggle","collapse");
    h4_a.setAttribute("data-parent","#accordion");
    
    if(con==1){
        chk = "select"+criteriaSet[i].criteria_id;
    }else{
        chk = "notSelect"+criteriaSet[i].criteria_id;
    }
    h4_a.setAttribute("href","#"+chk);
    //h4_a.setAttribute("onclick","pageChange("+chk+")");
    h4_a.innerHTML=criteriaSet[i].criteria_title;

    var h4_i_change = document.createElement("i");
    heading_h4.appendChild(h4_i_change);
    h4_i_change.setAttribute("class","fa fa-pencil fa-fw");
    //midChange
    //h4_i_change.setAttribute("onclick","midTitlechange("+criteriaSet[i].criteria_id+","+criteriaSet[i].criteria_state+")");
    h4_i_change.setAttribute("onclick","updateTitle("+criteriaSet[i].criteria_id+","+criteriaSet[i].criteria_state+")");

    var h4_i_remove = document.createElement("i");
    heading_h4.appendChild(h4_i_remove);
    h4_i_remove.setAttribute("class","glyphicon glyphicon-trash fa-fw");
    h4_i_remove.setAttribute("onclick","remove_midTitle("+criteriaSet[i].criteria_id+","+criteriaSet[i].criteria_state+")");

    var h4_spal = document.createElement("span");
    heading_h4.appendChild(h4_spal);
    h4_spal.setAttribute("class","pull-right");

    var h4_spal_i = document.createElement("i");
    h4_spal.appendChild(h4_spal_i);
    h4_spal_i.setAttribute("class","fa fa-arrow-circle-down fa-fw");

}

function logP(mes, con){
    if(con==1){
        return;
    }
    console.log(mes);    
}

