//선전조건 추가하기
//1. 선정조건
//선정, 제외 조건
function selectCondition() {
    var result =
        '\
    <div class="panel-body" style="padding:0px;" >\
       <div class="panel-group" id="accordion">\
            <div class="panel panel-default" >\
                <div class="panel-heading">\
                    <h4 class="panel-title">\
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" onClick="change(\'icon1\')">1. 생년월일 설정 \
                        </a>\
                        <i class="fa fa-pencil fa-fw" onClick="change(icon1)"></i><i class="glyphicon glyphicon-trash fa-fw"></i>\
                        <spal class="pull-right" id="icon1"> <i class="fa fa-arrow-circle-down fa-fw"></i></spal>\
                    </h4>\
                </div>\
                <div id="collapseOne" class="panel-collapse collapse in">\
                    <div class="panel-body" id="probGroup1" style="padding:0px; padding-left: 50px; " >\
                    \
                    </div>\
                </div>\
            </div>\
            <div class="panel panel-default">\
                <div class="panel-heading">\
                    <h4 class="panel-title">\
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" onClick="change(\'icon2\')">2. Sodium Chloride 0.154 MEQ/ML Injectable Solution 처방 받은 환자\
                        <spal class="pull-right" id="icon2"><i class="fa fa-arrow-circle-up fa-fw"></i></spal>\
                        </a>\
                    </h4>\
                </div>\
                <div id="collapseTwo" class="panel-collapse collapse">\
                    <div class="panel-body" id="probGroup2" style="padding:0px; padding-left: 50px; " >\
                    \
                    </div>\
                </div>\
            </div>\
        </div>\
    </div> \
';
 
return result;
}

function selectDiscondition(){
    var result='<div class="panel-body" style="padding:0px;" >\
                            <div class="panel-group" id="accordion1">\
                                <div class="panel panel-default" >\
                                    <div class="panel-heading">\
                                        <h4 class="panel-title">\
                                            <a data-toggle="collapse" data-parent="#accordion1" href="#collapseOne1">1. 고혈압 관련 약을 처방받은 환자.<spal class="pull-right" id="icon4"><i class="fa fa-arrow-circle-down fa-fw"></i></spal>\</a>\
                                        </h4>\
                                    </div>\
                                    <div id="collapseOne1" class="panel-collapse collapse in">\
                                        <div id="disproGroup" class="panel-body" style="padding:0px; padding-left: 50px;">\
                                            \
                                        </div>\
                                    </div>\
                                </div>\
                            </div>\
                        </div> \
';
 
return result;
}



//쿼리 리스트에 뿌리기
function viewQueryList(querylist){
        document.getElementById("querylist").innerHTML="";
    for(var i = 0; i < querylist.length ; i++){
        var createTR    = document.createElement("tr");
        document.getElementById("querylist").appendChild(createTR);
        
        // checkbox
        var checkBoxTd  = document.createElement("td");
        var checkBox    = document.createElement("input");
        checkBox.setAttribute("class","queryChk");
        checkBox.setAttribute("type","checkbox");
        checkBox.setAttribute("id","queryChk_"+i);
        
        checkBoxTd.appendChild(checkBox);
        createTR.appendChild(checkBoxTd);
        
        // title //version// 생성자 // 생성일 // 마지막수정자 // 마지막수정일 // 마지막 실행일 // 상태
        //index
        var tdbuf      = document.createElement("td");
        tdbuf.setAttribute("id","queryIndex_"+i);
        var txtbuf  = document.createTextNode(i);
        tdbuf.appendChild(txtbuf);
        createTR.appendChild(tdbuf); 

        //Title
        var tdbuf      = document.createElement("td");
        var txtbuf  = document.createTextNode(querylist[i].query_title);
        tdbuf.appendChild(txtbuf);
        createTR.appendChild(tdbuf); 
        
        //생성자
        tdbuf      = document.createElement("td");
        txtbuf  = document.createTextNode(querylist[i].query_creator);
        tdbuf.appendChild(txtbuf);
        createTR.appendChild(tdbuf);

        //생성일
        tdbuf      = document.createElement("td");
        txtbuf  = document.createTextNode(querylist[i].query_create_date);
        tdbuf.appendChild(txtbuf);
        createTR.appendChild(tdbuf);

        //마지막수정자
        tdbuf      = document.createElement("td");
        txtbuf  = document.createTextNode(querylist[i].query_last_editor);
        tdbuf.appendChild(txtbuf);
        createTR.appendChild(tdbuf);
        
        //마지막수정일
        tdbuf      = document.createElement("td");
        txtbuf  = document.createTextNode(querylist[i].query_modify_date);
        tdbuf.appendChild(txtbuf);
        createTR.appendChild(tdbuf);

        //마지막 실행일
        tdbuf      = document.createElement("td");
        txtbuf  = document.createTextNode(querylist[i].query_exe_date);
        tdbuf.appendChild(txtbuf);
        createTR.appendChild(tdbuf);

        // 상태 start, running, finish
        tdbuf      = document.createElement("td");
        txtbuf  = document.createTextNode(querylist[i].query_status);
        tdbuf.appendChild(txtbuf);
        createTR.appendChild(tdbuf);

        tdbuf   = document.createElement("td");
        btnbuf  = document.createElement("BUTTON");
       // btnbuf.setAttribut("type","BUTTON");
        btnbuf.setAttribute("class","btn btn-info btn-sm");
        btnbuf.setAttribute("onClick","edit_getCriteriaSet("+querylist[i].query_id+")");
        btnbuf.setAttribute("style","background-color: rgb(32,56,100); color: white; border-color: transparent");
        txtbuf= document.createTextNode("edit1");
        btnbuf.appendChild(txtbuf);
        tdbuf.appendChild(btnbuf);
        createTR.appendChild(tdbuf);
    }
}

//쿼리 생성.
function createQuery(title,name){
    console.log(querySet.length);
    var cnt = querySet.length;
    cnt = cnt +1;
    querySet.push(makeQuery(cnt,title, name));
    viewQueryList(querySet);
}
//쿼리 리스트 삭제.
function deleteQuery(){
    alert($('.queryChk:checkbox:checked'));
    var deleteList = $('.queryChk:checkbox:checked');
    //console.log(deleteList);
    var delIndexList = [];
    for(var i =0;i<deleteList.length;i++){
        delIndexList.push(((deleteList[i].id).split("_"))[1]);
    }
    alert("삭제 하시겠습니까?"+delIndexList);
    for(var i=delIndexList.length-1;i>=0;i--){
        querySet.splice(delIndexList[i],1);
    }
    viewQueryList(querySet);
}

/////////////////// DAO Start//////////////////////////////
// Query 관련 함수 //
function getQueryList(){
   
    var xhr = new XMLHttpRequest();
    var data;
    var querylist;
    xhr.onreadystatechange = function(){
        if(this.readyState == this.DONE && this.status == 200){
            
            var gettext = xhr.responseText;
            
            querylist = JSON.parse(gettext);
            //querylist= querylist.querylist; //{querylist:[]}
            querySet=querylist;
            viewQueryList(querylist);
        }
    }// change

    xhr.open("GET", "http://127.0.0.1:52273/query");
    xhr.send();
}

// CriteriaSet 요청 ///
function getCriteriaQuery(index){
    //console.log("getCriteriaQuery 호출");
    var xhr = new XMLHttpRequest();
    var data;
    var result;
    xhr.onreadystatechange = function(){
        if(this.readyState == this.DONE && this.status == 200){
            
            var gettext = xhr.responseText;
            
            result = JSON.parse(gettext);
            //console.log("getCriteriaQuery()"+index);
            //querylist= querylist.querylist; //{querylist:[]}
            criteriaSet=[];
            criteriaSet=result;
            //console.log(criteriaSet.length);
            viewSelectionMiddleCondition(criteriaSet);
            //notIncludecondition
            document.getElementById("includecondition").innerHTML="";
            document.getElementById("notIncludecondition").innerHTML=""
            document.getElementById("includecondition").appendChild(viewSelectionMiddleCondition(criteriaSet,1));
            document.getElementById("notIncludecondition").appendChild(viewSelectionMiddleCondition(criteriaSet,2));
            //document.getElementById("includecondition").innerHTML = viewSelectionMiddleCondition()
            $('#queryEdit').modal('show');
            //console.log("getCriteriaQuery 끝");
        }
    }// change

    xhr.open("GET", "http://127.0.0.1:52273/criteria/"+index);
    xhr.send();
}
