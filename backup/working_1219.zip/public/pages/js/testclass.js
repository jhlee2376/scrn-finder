//CriteriaSet관련

var creteriaSet = [];
var creteria_detailSet =[];
var querySet =[];

creteriaSet.push(Criteria(1,"20세 이하 남성"));
creteriaSet.push(Criteria(1,"50세 이상 여성"));

creteria_detailSet.push(Criteria_detail(1,"person","birth_of_year",3,"1900"));
creteria_detailSet.push(Criteria_detail(2,"person","birth_of_year",3,"1900"));
creteria_detailSet.push(Criteria_detail(3,"person","birth_of_year",3,"1900"));

