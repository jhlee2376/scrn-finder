function BigSet(bigName){
    var obj =[];
    boj ={
        bigName : bigName,
        midSet: midSet
    }
}

