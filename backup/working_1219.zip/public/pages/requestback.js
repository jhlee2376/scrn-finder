//siteNavi/corp_id/studylist
// #, 제목, 생성자, 담당자, 시작일시, 종료일시, 상태

// 1. 서버에 요청하기. 
// 2. 받은 JSON을 바탕으로 게시판에 맞게 HTML 만들기

function callStudyList(corp_id, user_id){


}

function addStudy(corp_id, user_id, subject, description){
    // 1. 서버에 저장한다.
    // 2. 갱신된 리스트를 가져온다. 
    // 3. 게시판에 뿌려준다.

    var request = new XMLHttpRequest();
    request.open('GET','localhost:8090:/',false);

    request.send();
    alert(requtest.responseText);
}