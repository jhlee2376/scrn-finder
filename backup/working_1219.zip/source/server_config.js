var dbConfig = {
    user: 'sa',
    password: 'scrn123!!',
    server: '127.0.0.1',
    port: '1433',
    database: 'SCRN_CLOUD',
    connectionTimeout: 3000000,
    requestTimeout: 3000000,
    pool:{
        idleTimeoutMillis :15000000,
        requestTimeout: 15000000
    }
}

var CdmDbConfig = {
    user: 'sa',
    password: 'scrn123!!',
    server: '127.0.0.1',
    port: '1433',
    database: 'BIGDATADB',
    connectionTimeout: 3000000,
    requestTimeout: 3000000,
    pool:{
        idleTimeoutMillis :15000000,
        requestTimeout: 15000000
    }
}

module.exports ={
    dbConfig,CdmDbConfig
}

